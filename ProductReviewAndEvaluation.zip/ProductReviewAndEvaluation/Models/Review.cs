﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

namespace ProductReviewAndEvaluation.Models
{
    public class Review
    {
    }

    public class ProductANSI
    {
        [Required]
        [Display(Name = "ANSI")]
        public string Number { get; set; }
    }
    public class StarReview
    {
        [Required]
        [Display(Name = "Star")]
        public string Number { get; set; }
    }
    public class ProductReview
    {
        [Required]
        [Display(Name = "Review")]
        public string Number { get; set; }
    }
}