﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

namespace ProductReviewAndEvaluation.Models
{
    public class User
    {
        public string AmtrackId { get; set; }
        public string Gender { get; set; }
        public string Country { get; set; }
        public string Education { get; set; }
        public string Job { get; set; }
        public string Salary { get; set; }
    }

    public class AmtrackId
    {
        [Required]
        [Display(Name = "AmtrackId")]
        public string Number { get; set; }
    }

    public class Gender
    {
        [Required]
        [Display(Name = "Gender")]
        public string Number { get; set; }
    }

    public class Country
    {
        [Required]
        [Display(Name = "Country")]
        public string Number { get; set; }
    }

    public class Education
    {
        [Required]
        [Display(Name = "Education")]
        public string Number { get; set; }
    }

    public class Job
    {
        [Required]
        [Display(Name = "Job")]
        public string Number { get; set; }
    }

    public class Salary
    {
        [Required]
        [Display(Name = "Salary")]
        public string Number { get; set; }
    }


}
