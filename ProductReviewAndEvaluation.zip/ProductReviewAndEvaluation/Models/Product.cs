﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;
namespace ProductReviewAndEvaluation.Models
{
    public class Product
    {
        public string ANSI { get; set; }
        public string ProductName { get; set; }
        public string Brand { get; set; }
        public string Model { get; set; }
        public int Cost { get; set; } 
        public string TotalReview { get; set; }
        
    }


    public class ANSI
    {
        [Required(ErrorMessage ="ANSI of the product is required")]
        [Display(Name = "ANSI")]
        public string Number { get; set; }
    }


    public class ProductName
    {
        [Required]
        [Display(Name = "ProductName")]
        public string Number { get; set; }
    }

    public class Brand
    {
        [Required]
        [Display(Name = "Brand")]
        public string Number { get; set; }
    }


    public class Model
    {
        [Required]
        [Display(Name = "Model")]
        public string Number { get; set; }
    }


    public class Cost
    {
        [Required]
        [Display(Name = "Cost")]
        public string Number { get; set; }
    }


    public class TotalReview
    {
        [Required]
        [Display(Name = "TotalReview")]
        public string Number { get; set; }
    }


}